using UnityEngine;


namespace DD.Web3
{
    public interface IClaimAmountProvider
    {
        int GetClaimAmount();
    }
}

