using UnityEngine;


namespace DD.Web3
{
    //[CreateAssetMenu(fileName = "BuildNetworkSO", menuName = "Scriptable Objects/Blockchain/BuildNetwork")]
    public class BuildNetworkSO : ScriptableObject
    {
        public BlockchainNetwork selectedNetwork;
    }
}


